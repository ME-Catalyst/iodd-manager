Readme.txt

This directory contains two folders:

01_EDS:   contains EDS and related changehistory and readme files
02_IOLM:  contains IOLM and related bitmap files to be used in Murrelektronik IOL Device Tool V4
