This folder includes the Konfigurationsfiles for 
56535 Cube67 Bud node V2
with Firmware Major Release 1.00-1.05 use 56535_Cube67+BNEV2_kfg_x_19
with Firmware Major Release 2.00-2.03 use 56535_Cube67+BNEV2_kfg_x_31

If you are not sure which version you have, 
you will find it printed on the device on the side or in the web server.